import React, { Component } from 'react'
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box } from "@material-ui/core";
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import ApiService from "../ApiService";
import AddImg from './images/add.png';
import AddBox from '@material-ui/icons/AddBox';
import './css/editOrder.css';

import RefreshIcon from '@material-ui/icons/Refresh';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';


class CreateShop extends Component {

    constructor(props){
        super(props);
        this.state ={
          shopId:"",
          shopName:"",
          phone:"",
          address:"",
          description:"",
          imgURL:"",
          ownerId:"",

          permission:false,

          file1:"",
          imagePreviewUrl1:"",

          message:"",
          severity:"",
          alertTitle:"",

        }
        // this.saveUser = this.saveUser.bind(this);
        // this.loadUser = this.loadUser.bind(this);
    }


    componentDidMount() {
        // custom rule will have name 'isName'
        const shopId = this.props.match.params.id;
        this.loadShop(shopId)

        ValidatorForm.addValidationRule('isShopName', (value) => {
            if ((this.state.shopName.length) >2 && (this.state.shopName.length) <20){
                return true;
            }
            return false;
        });

        // custom rule will have name 'isPassword'
        ValidatorForm.addValidationRule('isPhone',(value) => {
            if ((this.state.phone.length) > 9 && (this.state.phone.length) < 12) {
                return true;
            }
            return false;
        });

        if(localStorage.getItem("shopId") == 'undefined'){
            this.setState({
              shops:'',
            })
        }else {
            this.setState({
              shopId:localStorage.getItem("shopId"),
            })
        }

    }

    componentWillUnmount() {
        // remove rule when it is not needed
        ValidatorForm.removeValidationRule('isShopName');
        ValidatorForm.removeValidationRule('isPhone');
    }



    onChange = (e) =>{
        this.setState({ [e.target.name]: e.target.value });
    }


    loadShop = (shopId) => {
        ApiService.getShopById(shopId)
            .then(res => {
                this.setState({
                    shopId:res.data.shopId,
                    shopName:res.data.shopName,
                    phone:res.data.telephone,
                    address:res.data.address,
                    description:res.data.description,
                    imagePreviewUrl1:res.data.shopLogo,
                    ownerId:res.data.ownerId,
                })
                if(res.data.ownerId == localStorage.getItem("userId")){
                    this.setState({
                        permission:true,
                    })
                }else {
                  this.setState({
                      permission:false,
                  })
                }
            })

    }




    updateShop = () => {
        let shop = {
          shopId: this.state.shopId,
          ownerId:this.state.ownerId,
          shopName: this.state.shopName,
          description:this.state.description,
          telephone: this.state.phone,
          address: this.state.address,
          shopLogo:this.state.imagePreviewUrl1,
        };
        ApiService.updateShop(shop)
            .then(res => {
                this.setState({
                  message : 'Shop create successfully.',
                  alertTitle:'success',
                  severity:"success",
                })

                ApiService.getShopByUserId(localStorage.getItem("userId"))
                .then((res) => {
                  localStorage.setItem("shopId",res.data.shopId);
                  setTimeout(() => {
                      this.props.history.push('/shop/'+res.data.shopId);
                  },2500);
                })

            })
            .catch((err) => {
               this.setState({message:"Shop create Failed.",severity:"error",alertTitle:"Failed"});
               setTimeout(() => {
                   this.setState({message:"",severity:"",alertTitle:""});
               },2500);
            })
    }

    reload = () => {
       window.location.reload()
    }


    _handleImage1Change1(e) {
      e.preventDefault();

      let reader1 = new FileReader();
      let file1 = e.target.files[0];
      reader1.readAsDataURL(file1)
      reader1.onloadend = () => {
        this.setState({
          file1: file1,
          imagePreviewUrl1: reader1.result,
        });
      }


    }


    render() {
        let {imagePreviewUrl1} = this.state;


        return (
          <div >
                {this.state.message&&(
                  <div>

                      <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                            <AlertTitle>{this.state.alertTitle}</AlertTitle>
                            {this.state.message}
                      </Alert>
                  </div>
                )}
            {this.state.permission&&(
                <Paper style={{position:'relative',width:'90%',margin:'auto',top:'50px'}} elevation={1}>
                  <Typography id="profileHeading">Edit Shop</Typography>

                    <ValidatorForm onSubmit={() => this.updateShop()} >
                        <Grid container id="profileGrid">


                          <Grid item xs={12} sm={12} md={6}>
                            <Paper style={{height:'150px',width:'90%',margin:'auto',marginTop:'15px',}} elevation={3}>
                                <Typography variant="h6" id="userNameDivTitle">Shop Logo</Typography>
                                <div style={{float: 'left',marginTop: '10px',width: '100px',height: '100px',border: '1px solid black',marginLeft: '40px',}}>
                                    <input className="fileInput1"
                                      type="file"
                                      accept="image/*"
                                      onChange={(e)=>this._handleImage1Change1(e)}
                                     />

                                     {!imagePreviewUrl1&&(
                                        <img src={AddImg} className="addItemImg1" />
                                      )}
                                        <img src={imagePreviewUrl1} className="addItemImg1" />
                                </div>
                            </Paper>
                          </Grid>




                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="userNameDiv"  elevation={3}>
                                <Typography variant="h6" id="userNameDivTitle">Shop Name</Typography>

                                <TextValidator

                                    variant="outlined"
                                    label="Shop Name"
                                    onChange={this.onChange}
                                    name="shopName"
                                    value={this.state.shopName}
                                    Id="firstNameIp"
                                    validators={['required','isShopName']}
                                    errorMessages={['This field is required','The shop name must be between 3 and 20 charactes']}
                                />

                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="phoneDiv" elevation={3}>
                                <Box id="phonebox">
                                    <Typography variant="h6" id="lastNameDivTitle">Phone Number</Typography>

                                        <TextValidator
                                            variant="outlined"
                                            label="Phone Number"
                                            onChange={this.onChange}
                                            name="phone"
                                            value={this.state.phone}
                                            Id="firstNameIp"
                                            type="Number"
                                            validators={['required','isPhone']}
                                            errorMessages={['This field is required','The phone number must 10 digit.']}
                                        />

                                </Box>
                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="addressDiv" elevation={3}>
                                <Box id="addressbox">
                                    <Typography variant="h6" id="lastNameDivTitle">Address</Typography>

                                        <TextValidator
                                            variant="outlined"
                                            label="Address"
                                            onChange={this.onChange}
                                            name="address"
                                            value={this.state.address}
                                            Id="firstNameIp"
                                            validators={['required']}
                                            errorMessages={['This field is required']}
                                        />
                                </Box>
                            </Paper>
                          </Grid>

                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="descriptionDiv" elevation={3} style={{height:"170px",width:"90%",margin:"auto",marginTop:"10px"}}>
                                <Box id="descriptionbox">
                                    <Typography variant="h6" id="lastNameDivTitle">Description</Typography>
                                        <textarea value={this.state.description} name="description" placeholder="Description....." onChange={this.onChange} style={{width:"90%",height:"100px",display:"flex",margin:"auto",marginTop:"10px",resize:"none"}}>

                                        </textarea>

                                </Box>
                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} >
                              <Box style={{float:'right',marginRight:'40px'}}>
                                <Button style={{marginTop:'30px',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white',marginRight:'10px'}} onClick={() => this.reload()}> <RefreshIcon/>  Reset</Button>
                                <Button type="submit" style={{marginTop:'30px',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white'}}> <AddBox style={{marginRight:'5px'}}/> Update</Button>

                              </Box>
                          </Grid>
                    </Grid>
                    </ValidatorForm>
                    <br/><br/><br/><br/>
                </Paper>
            )}
            {!this.state.permission &&(
              <Paper style={{width:"90%",margin:"auto",position:"relative",top:"50px",minHeight:"100px"}} elevation={5}>
                  <Typography variant="h4" style={{textAlign:"center",position:"relative",top:"20px"}}>Ops... Sorry this is not your shop.</Typography>
                {/*
                  <Typography variant="h6" style={{textAlign:"center",position:"relative",top:"20px"}}><a href={"/shop/"+this.state.shopId} style={{textDecoration:"none",color:"blue"}}>Click here to go to your shop.</a></Typography>
                */}
              </Paper>
            )}
        </div>

        );
    }
}

export default CreateShop;
