import React, { Component } from 'react'
import {Link} from 'react-router-dom'
import {DataContext} from '../component/Data'
import './css/ShopSide.css'
import ApiService from "./../ApiService";
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';

import Rating from 'material-ui-rating';
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea,Box} from '@material-ui/core';

export class ShopSide extends Component {
  constructor(props) {
    super(props)
    this.state={
      shop_owner_username:'',
      userId:localStorage.getItem("userId"),


      shop:[],
      products:[],

      shopId:"",
      ownerId:"",
      description:"",
      address:"",
      telephone:"",
      product:"",
      shopName:"",
      shopLogo:"",
      rating:"",

      file1:"",

      thisOwer:false,

    };
  }

  componentDidMount(){
    const shopId = this.props.match.params.id;
    this.loadShop(shopId)
    this.loadProduct(shopId)
  }


  loadShop = (shopId) => {
      ApiService.getShopById(shopId)
          .then((res) => {
            //  console.log("shops :- " + res.data);
              let shops = res.data;
              this.setState({
                  shop:shops,
                  shopId: shops.shopId,
                  ownerId: shops.ownerId,
                  description: shops.description,
                  address: shops.address,
                  telephone: shops.telephone,
                  product: shops.product,
                  shopName: shops.shopName,
                  shopLogo: shops.shopLogo,
                  rating: shops.rating,

                  file1: shops.shopLogo,
              })
              if(shops.ownerId == this.state.userId){
                this.setState({
                  thisOwer:true,
                })
              }else {
                this.setState({
                  thisOwer:false,
                })
              }

          });

  }


  loadProduct = (shopId) => {
    ApiService.getProductByShopId(shopId)
        .then((res) => {
          let products = res.data.data;
          this.setState({
              products:products,
          })
        })
  }

    static contextType = DataContext;

    state = {value:3};

    render() {
        const {addCart,buythins} = this.context;
        const shop = this.state.shop;
        const products = this.state.products;

        return (
            <div>
                  <div style={{position:"relative",top:"50px"}}>
                          <Card className= "shopCover" elevation= {10}>

                                    <CardMedia style={{width:'200px',height:'200px',marginTop:'30px',marginLeft:'30px'}}>
                                        {shop.shopLogo&&(
                                          <img src= {shop.shopLogo} alt="Logo" className= "ShopProfilePhoto"/>
                                        )}
                                    </CardMedia>

                                  <CardContent className="shopNameCover">
                                      <Typography gutterBottom variant="h5" component="h2" className="shopname" style={{fontWeight:'bold'}}>
                                          {shop.shopName}
                                      </Typography>

                                      <Typography>
                                        <Rating name="read-only" value={shop.rating} readOnly />
                                      </Typography>



                                  </CardContent>
                                  {this.state.thisOwer&&(
                                    <Button id="shopEditeBtn" href={"/editShop/"+shop.shopId} >EDIT</Button>

                                  )}
                                  {this.state.thisOwer&&(

                                    <Button id="shopEditeBtn" href="/additem">Add Product</Button>
                                  )}


                          </Card>




                {/*<div id="Shop">
                  {
                        products.map(product =>(
                           <div className="card" key={product._id}>
                               <Link to={`/product/${product._id}`}>
                                   <img  src={product.src} alt=""/>
                               </Link>
                               <div className="content">
                                   <h3>
                                       <Link to={`/product/${product._id}`}>{product.title}</Link>
                                   </h3>
                                   <span>Rs.{product.sellPrice}</span>
                                   <p>{product.description}</p>
                                   <Rating name="read-only" value={product.rating} readOnly style={{}} />
                                    <Box>
                                        <Button style={{backgroundColor:'red'}}>Hii</Button>
                                        <Button id="item_B" onClick={()=> addCart(product._id)}>Add to cart</Button>
                                        <Button id="item_B" onClick={()=> buythins(product._id)} href='/payment'>buy now</Button>
                                        <Button id="item_B">EDIT</Button>
                                    </Box>
                               </div>
                           </div>
                         ))
                  }
                </div>*/}

                <div  className='shopResultDiv'>
                  <Grid container >
                  {products&&(
                          products.map(product =>(
                              <Grid item xs={6} sm={4} md={3} lg={3} style={{marginTop:'20px'}}  >
                                      <Card className='productCard' key={product.id}  elevation={3}>
                                        <CardActionArea href={'/product/'+product.productId}>
                                          <Box className='showImgDiv'>
                                            <CardMedia
                                              className='showImg'
                                              component="img"
                                              image={product.image1}
                                              title="Contemplative Reptile"
                                              class="img-responsive"
                                              id="showImg"
                                            />
                                          </Box>
                                          <CardContent>
                                            <Typography gutterBottom  className='productTitle'>
                                            {product.title}
                                            </Typography>
                                            <Typography className='offerPrice' variant="h6">
                                              {product.lastPrice}
                                            </Typography>
                                              <Typography className='sellPrice' variant="h6">
                                              {product.sellPrice}
                                              </Typography>
                                              <Typography className='offerPrice'>
                                                  <Rating name="read-only" value={product.rating} readOnly style={{}} />
                                              </Typography>
                                          </CardContent>
                                        </CardActionArea>
                                        <CardActions >
                                        <Button variant="contained" id="btn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} >
                                            Buy now
                                        </Button>
                                        <Button variant="contained" onClick={()=> addCart(product.productId)} style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} ><ShoppingCartIcon/>
                                            Add to cart
                                        </Button>
                                        </CardActions>
                                        {this.state.thisOwer&&(
                                            <Button variant="contained"  style={{backgroundColor:'#03a9f4',color:'white',display:'flex',margin:'auto',width:"80%"}} href={"/editProduct/"+product.productId} >
                                                Edit product
                                            </Button>
                                        )}
                                        <br/><br/>
                                      </Card>
                              </Grid>
                          ))
                  )}

                  </Grid>
                </div>
            </div>
        </div>
    )
}
}

export default ShopSide;
