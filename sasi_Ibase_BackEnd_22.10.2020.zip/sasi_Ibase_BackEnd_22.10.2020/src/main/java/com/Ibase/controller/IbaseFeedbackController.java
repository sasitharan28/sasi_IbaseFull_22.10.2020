package com.Ibase.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ibase.model.IbaseFeedback;
import com.Ibase.service.IbaseFeedbackService;


@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/api/feedback")
public class IbaseFeedbackController {
	
	@Autowired
	IbaseFeedbackService ibaseFeedbackService;
	
	@GetMapping
	public ResponseEntity<Map<String, Object>> getAllProducts(
			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
			@RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
			@RequestParam(name = "sortBy", defaultValue = "feedbackDate") String sortBy){
		
		return ibaseFeedbackService.getAllFeedback(pageNo,pageSize,sortBy);
	}
	
	@PostMapping
	public ResponseEntity<IbaseFeedback> createFeedback(@RequestBody IbaseFeedback feedback){
		return ibaseFeedbackService.createFeedback(feedback);
	}
	
	@GetMapping("/{feedbackId}")
	public ResponseEntity<IbaseFeedback>getFeedbackById(@PathVariable String feedbackId){
		return ibaseFeedbackService.getFeedbackById(feedbackId);
	}
	
	@GetMapping(params="productId")
	public ResponseEntity<List<IbaseFeedback>> getFeedbackByProductId(
			@RequestParam String productId){
		return ibaseFeedbackService.getFeedbackByProductId(productId);
	}
	
//	@GetMapping(params="productId")
//	public ResponseEntity<Map<String,Object>> getFeedbackByProductId(
//			@RequestParam (name = "productId")String productId,
//			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
//			@RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
//			@RequestParam(name = "sortBy", defaultValue = "feedbackDate") String sortBy){
//		return ibaseFeedbackService.getFeedbackByProductId(pageNo,pageSize,sortBy,productId);
//	}
	
	
	
	@GetMapping(params="pro")
	public ResponseEntity<Long> countFeedbackByProductId(@RequestParam String pro){
		return ibaseFeedbackService.countFeedbackByProductId(pro);
	}
}
