
package com.Ibase.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Product")
public class IbaseProduct {
	@Id
	private String productId;
	private String shopId;
	private String title;
	private String description;
	private double lastPrice;
	private double sellPrice;
	private int warranty;
	private double rating;
	private int stock;
	private String brand;
	private String model;
	private String category;
	private Date date;
	
	private String image1;
	private String image2;
	private String image3;
	private String image4;
	private String image5;
	
	
//	private String feedBack;
//	private byte[] images;
	
	
	public IbaseProduct(String productId, String shopId, String title, String description, double lastPrice,
			double sellPrice, int warranty, double rating, int stock, String brand, String model , String category , Date date ,String image1 ,String image2 ,String image3 ,String image4 ,String image5 ) {
		super();
		this.productId = productId;
		this.shopId = shopId;
		this.title = title;
		this.description = description;
		this.lastPrice = lastPrice;
		this.sellPrice = sellPrice;
		this.warranty = warranty;
		this.rating = rating;
		this.stock = stock;
		this.brand = brand;
		this.model = model;
		this.category = category;
		this.date = date;
		this.image1 = image1;
		this.image2 = image2;
		this.image3 = image3;
		this.image4 = image4;
		this.image5 = image5;
//		this.feedBack = feedBack;
	}


	

	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getproductId() {
		return productId;
	}


	public void setproductId(String productId) {
		this.productId = productId;
	}


	public String getshopId() {
		return shopId;
	}


	public void setshopId(String shopId) {
		this.shopId = shopId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public double getLastPrice() {
		return lastPrice;
	}


	public void setLastPrice(double lastPrice) {
		this.lastPrice = lastPrice;
	}


	public double getSellPrice() {
		return sellPrice;
	}


	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}


	public int getWarranty() {
		return warranty;
	}


	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}


	public int getStock() {
		return stock;
	}


	public void setStock(int stock) {
		this.stock = stock;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}
	
	
	
	
	
	
	
	public Date getDate() {
		return date;
	}




	public void setDate(Date date) {
		this.date = date;
	}




	public String getImage1() {
		return image1;
	}


	public void setImage1(String image1) {
		this.image1 = image1;
	}
	
	public String getImage2() {
		return image2;
	}


	public void setImage2(String image2) {
		this.image2 = image2;
	}


	public String getImage3() {
		return image3;
	}


	public void setImage3(String image3) {
		this.image3 = image3;
	}


	public String getImage4() {
		return image4;
	}


	public void setImage4(String image4) {
		this.image4 = image4;
	}


	public String getImage5() {
		return image5;
	}


	public void setImage5(String image5) {
		this.image5 = image5;
	}



	@Override
	public String toString() {
		return "IbaseProduct [productId=" + productId + ", shopId=" + shopId + ", title=" + title + ", description="
				+ description + ", lastPrice=" + lastPrice + ", sellPrice=" + sellPrice + ", warranty=" + warranty
				+ ", rating=" + rating + ", stock=" + stock + ", brand=" + brand + ", model=" + model + "]";
	}


	


//	public String getFeedBack() {
//		return feedBack;
//	}
//
//
//	public void setFeedBack(String feedBack) {
//		this.feedBack = feedBack;
//	}
	
	

}
