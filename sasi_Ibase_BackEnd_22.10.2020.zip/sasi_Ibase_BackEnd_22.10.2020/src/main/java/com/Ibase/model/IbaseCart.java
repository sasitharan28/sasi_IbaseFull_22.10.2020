package com.Ibase.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Date;


@Document(collection = "cart")
public class IbaseCart {
	@Id
	private String cartId;
	private String productId;
	private String shopId;
	private int quantity;
	private double price;
	private Date  date;
	
	private IbaseCart(String cartId, String productId, String shopId, int quantity, double price, Date date) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.shopId = shopId;
		this.quantity = quantity;
		this.price = price;
		this.date = date;
	}
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
	
	
	
}
