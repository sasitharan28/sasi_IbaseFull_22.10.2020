package com.Ibase.model;

public enum IbaseERole {
	USER_ROLE,
	SHOP_ROLE,
	ADDMIN_ROLE
}
