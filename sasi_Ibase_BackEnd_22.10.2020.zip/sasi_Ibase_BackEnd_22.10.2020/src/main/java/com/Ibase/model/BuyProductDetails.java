package com.Ibase.model;

import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class BuyProductDetails {
	
	@Id
	private String buyProductId;
	@NotEmpty(message = "ShopId must not be empty")
	private String shopId;
	private int quantity;
	private Double price;
	private String orderSubId;
	
	
	
	
	
	
	public BuyProductDetails( String buyProductId , int quantity , Double price , String shopId , String orderSubId) {
		super();
		this.buyProductId = buyProductId;
		this.quantity = quantity;
		this.price = price;
		this.shopId = shopId;
		this.orderSubId = orderSubId;
	}


	


	public String getOrderSubId() {
		return orderSubId;
	}
	public void setOrderSubId(String orderSubId) {
		this.orderSubId = orderSubId;
	}





	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}




	public String getBuyProductId() {
		return buyProductId;
	}
	public void setBuyProductId(String buyProductId) {
		this.buyProductId = buyProductId;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}





	
	
}
