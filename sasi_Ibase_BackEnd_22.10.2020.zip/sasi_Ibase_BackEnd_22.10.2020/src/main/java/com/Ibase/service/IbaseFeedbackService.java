package com.Ibase.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Ibase.Repository.IbaseFeedbackRepository;
import com.Ibase.model.IbaseFeedback;

@Service
public class IbaseFeedbackService {
	@Autowired
	IbaseFeedbackRepository ibaseFeedbackRepository;

	public ResponseEntity<Map<String,Object>> getAllFeedback(int pageNo, int pageSize , String sortBy) {
		try {			
			Map<String, Object> response = new HashMap<>();
			Sort sort = Sort.by(sortBy);
			PageRequest pageable = PageRequest.of(pageNo,pageSize,sort);
			Page<IbaseFeedback> feedbacks = ibaseFeedbackRepository.findAll(pageable);
			response.put("data", feedbacks.getContent());
		    response.put("Total no of pages", feedbacks.getTotalPages());
		    response.put("Total no of elements", feedbacks.getTotalElements());
		    response.put("Current page no", feedbacks.getNumber());
		    if(feedbacks.isEmpty()) {
		    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    	return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
//	public ResponseEntity<Map<String, Object>> getAllProducts(int pageNo, int pageSize){
//		try {
//			Map<String, Object> response = new HashMap<>();
//			PageRequest pageable = PageRequest.of(pageNo,pageSize);
//			Page<IbaseProduct> product = ibaseProductRepository.findAll(pageable);
//			response.put("data", product.getContent());
//		    response.put("Total no of pages", product.getTotalPages());
//		    response.put("Total no of elements", product.getTotalElements());
//		    response.put("Current page no", product.getNumber());
//		    if(product.isEmpty()) {
//		    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//		    }else {
//		    	return new ResponseEntity<>(response, HttpStatus.OK);
//		    }
//		} catch (Exception e) {
//		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//		}	
//	}
	
	
	

	public ResponseEntity<IbaseFeedback> createFeedback(IbaseFeedback feedback) {
		try {
			IbaseFeedback upFeedback = ibaseFeedbackRepository.insert(feedback);
			return new ResponseEntity<>(upFeedback ,HttpStatus.CREATED);
			
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<IbaseFeedback> getFeedbackById(String feedbackId) {
		try {
			Optional<IbaseFeedback> feedback = ibaseFeedbackRepository.findById(feedbackId);
			if(feedback.isPresent()) {
				return new ResponseEntity<>( feedback.get() , HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<IbaseFeedback>> getFeedbackByProductId(String productId) {
		try {
			List<IbaseFeedback> feedback = ibaseFeedbackRepository.findByProductId(productId);
			if(feedback.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(feedback ,HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
//	public ResponseEntity<Map<String,Object>> getFeedbackByProductId(int pageNo, int pageSize , String sortBy,String productId) {
//		try {			
//			Map<String, Object> response = new HashMap<>();
//			Sort sort = Sort.by(sortBy);
//			PageRequest pageable = PageRequest.of(pageNo,pageSize,sort);
//			Page<IbaseFeedback> feedbacks = ibaseFeedbackRepository.findByProductId(pageable,productId);
//			response.put("data", feedbacks.getContent());
//		    response.put("Total no of pages", feedbacks.getTotalPages());
//		    response.put("Total no of elements", feedbacks.getTotalElements());
//		    response.put("Current page no", feedbacks.getNumber());
//		    if(feedbacks.isEmpty()) {
//		    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//		    }else {
//		    	return new ResponseEntity<>(response, HttpStatus.OK);
//		    }
//		}catch(Exception e) {
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	
//	public ResponseEntity<Map<String, Object>> getFeedbackByProductId(int pageNo, int pageSize , String sortBy , String productId){
//		try {
//			Map<String, Object> response = new HashMap<>();
//			Sort sort = Sort.by(sortBy);
//			Pageable pageable = PageRequest.of(pageNo,pageSize,sort);
//			Page<IbaseFeedback> feedbacks = ibaseFeedbackRepository.findByProductId(pageable,productId);
//
//			response.put("data", feedbacks.getContent());
//		    response.put("Total no of pages", feedbacks.getTotalPages());
//		    response.put("Total no of elements", feedbacks.getTotalElements());
//		    response.put("Current page no", feedbacks.getNumber());
//			    
//		    if(feedbacks.isEmpty()) {
//		    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//		    }else {
//		    	return new ResponseEntity<>(response, HttpStatus.OK);
//		    }
//		    
//		} catch (Exception e) {
//		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		
//	}
	

	public ResponseEntity<Long> countFeedbackByProductId(String pro) {
		try {
			Long totFeedback = ibaseFeedbackRepository.countByProductId(pro);
			if(totFeedback == 0) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				return new ResponseEntity<>(totFeedback , HttpStatus.OK);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
