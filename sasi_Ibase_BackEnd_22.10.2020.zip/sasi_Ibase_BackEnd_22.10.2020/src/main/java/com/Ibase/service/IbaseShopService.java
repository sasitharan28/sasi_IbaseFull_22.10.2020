package com.Ibase.service;


import org.springframework.data.domain.PageRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.Ibase.Repository.IbaseShopRepository;
import com.Ibase.model.IbaseShop;

@Service
public class IbaseShopService {
	
	@Autowired
	IbaseShopRepository ibaseShopRepository;
	
	
	
	public ResponseEntity<Map<String, Object>> getAllShops(int pageNo, int pageSize){
		try {
			Map<String, Object> response = new HashMap<>();
			PageRequest pageable = PageRequest.of(pageNo,pageSize);
			Page<IbaseShop> shops = ibaseShopRepository.findAll(pageable);

			response.put("data", shops.getContent());
		    response.put("Total no of pages", shops.getTotalPages());
		    response.put("Total no of elements", shops.getTotalElements());
		    response.put("Current page no", shops.getNumber());
			    
		    if(shops.isEmpty()) {
		    	return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    	return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		    
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	
	public ResponseEntity<IbaseShop> getShopById(String shopId) {
		try {
			Optional<IbaseShop> shop =ibaseShopRepository.findById(shopId);
			if(shop.isPresent()) {
				return new ResponseEntity<>(shop.get() ,HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	public ResponseEntity<IbaseShop> getShopByUserId(String userId) {
		try {
			Optional<IbaseShop> shop =ibaseShopRepository.findByOwnerId(userId);
			if(shop.isPresent()) {
				return new ResponseEntity<>(shop.get() ,HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	public ResponseEntity<IbaseShop> createShop(IbaseShop shop) {
		try {
			IbaseShop sho = ibaseShopRepository.insert(shop);
			return new ResponseEntity<>(sho,HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	public ResponseEntity<IbaseShop> updateShop(String shopId, IbaseShop newShop) {
		Optional <IbaseShop> oldShop = ibaseShopRepository.findById(shopId);
		if(oldShop.isPresent()) {
			IbaseShop _shop = oldShop.get();
			_shop.setOwnerId(newShop.getOwnerId());
			_shop.setShopName(newShop.getShopName());
			_shop.setDescription(newShop.getDescription());
			_shop.setAddress(newShop.getAddress());
			_shop.setTelephone(newShop.getTelephone());
			_shop.setShopLogo(newShop.getShopLogo());
			_shop.setProduct(newShop.getProduct());
			_shop.setRating(newShop.getRating());
			return new ResponseEntity<>(ibaseShopRepository.save(_shop),HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}



	public ResponseEntity deleteShopById(String shopId) {
		try {
			Optional<IbaseShop> shop = ibaseShopRepository.findById(shopId);
			if(shop.isPresent()) {
				ibaseShopRepository.deleteById(shopId);
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);	
			}else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}




	



	
	
	
}
